# Product Catalogue Microservice

This project implements the DevOps assignment using Node.js, Express, TypeScript, PostgreSQL, Prisma, Docker, Kubernetes, and GitHub Actions.

## API versions

| Version | Features |
|---|---|
| v1 | `GET /health`, `GET /products` |
| v1.1 | v1 + `GET /products/search?keyword=keyboard` |
| v2 | v1.1 + `page`, `limit`, `minPrice`, `maxPrice`; `POST /products`; validation and error handling |

## Local execution

```bash
cp .env.example .env
npm install
npm run prisma:generate
npx prisma migrate dev --name init
npm run prisma:seed
npm run dev
```

Open `http://localhost:3000/health`.

## Docker Compose

```bash
docker compose up --build -d
# In another shell, run migrations against the compose database if needed:
# docker compose exec api npx prisma migrate deploy
```

## Tests

```bash
npm test
```

## Docker build

```bash
docker build -t your-dockerhub-user/product-catalogue:v2.0.0 .
docker run --rm -p 3000:3000 --env-file .env your-dockerhub-user/product-catalogue:v2.0.0
```

## Kubernetes / Minikube

```bash
minikube start
kubectl apply -f kubernetes/namespaces
kubectl apply -f kubernetes/deployments
kubectl apply -f kubernetes/services
kubectl apply -f kubernetes/hpa
kubectl apply -f kubernetes/ingress.yaml
minikube addons enable ingress
kubectl get pods -A
kubectl get ingress -A
```

For a local Minikube image, run `eval $(minikube docker-env)` before building the image. Update the image name in the Deployment manifests if you use a registry.

## CI/CD

The GitHub Actions workflow runs tests, builds the image, pushes it to Docker Hub, and applies Kubernetes manifests. Configure these repository secrets:

- `DOCKERHUB_USERNAME`
- `DOCKERHUB_TOKEN`
- `KUBE_CONFIG_DATA` (base64-encoded kubeconfig)

## Logging and monitoring

The application logs to stdout/stderr. Kubernetes can collect these logs using its logging stack. The `/health` endpoint is used by Docker and Kubernetes probes. HPA uses resource metrics; install `metrics-server` in Minikube if it is not already enabled.

## Git versioning workflow

Create and tag the requested versions:

```bash
git add . && git commit -m "feat: initial v1 catalogue"
git tag v1.0.0
# implement v1.1 changes
git add . && git commit -m "feat: add product search"
git tag v1.1.0
# implement v2 changes
git add . && git commit -m "feat: add paginated search and validation"
git tag v2.0.0
```

The Kubernetes routing namespace uses `ExternalName` Services so one Ingress can route path prefixes to Services that live in the three isolated version namespaces. Replace the example database connection string with a real in-cluster PostgreSQL service and store it as a sealed/external secret in production.
