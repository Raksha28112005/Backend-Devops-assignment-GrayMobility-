import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function main() {
  const products = [
    { sku: 'KB-001', name: 'Mechanical Keyboard', description: 'Compact mechanical keyboard', price: 89.99 },
    { sku: 'MS-001', name: 'Wireless Mouse', description: 'Ergonomic wireless mouse', price: 29.99 },
    { sku: 'HD-001', name: 'USB-C Headphones', description: 'Noise-isolating headphones', price: 59.99 }
  ];

  for (const product of products) {
    await prisma.product.upsert({
      where: { sku: product.sku },
      update: product,
      create: product
    });
  }
}

main().finally(() => prisma.$disconnect());
