# System Design

The service is a stateless Express API backed by PostgreSQL through Prisma.

- **API layer:** Express routes validate input and map errors to HTTP responses.
- **Persistence:** PostgreSQL stores products; Prisma provides typed access and migrations.
- **Versioning:** `API_VERSION` selects v1, v1.1, or v2. Kubernetes exposes each version through a separate namespace and Ingress path.
- **Scalability:** API pods are stateless and can be horizontally replicated. HPA scales on CPU utilization.
- **Security:** secrets are supplied through Kubernetes Secrets or environment injection; the image runs as the non-root `node` user.
- **Observability:** `/health` checks database connectivity. Container logs are emitted to stdout/stderr for collection by the cluster runtime.
