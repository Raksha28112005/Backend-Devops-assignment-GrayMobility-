import request from 'supertest';
import { describe, expect, it } from 'vitest';
import { createApp } from '../src/app';

const fakeDb: any = {
  $queryRaw: async () => [{ '?column?': 1 }],
  product: {
    findMany: async () => [{ id: 1, sku: 'KB-001', name: 'Keyboard', price: 10 }],
    create: async ({ data }: any) => ({ id: 2, ...data })
  }
};

describe('product catalogue API', () => {
  it('returns health status', async () => {
    const response = await request(createApp('v2', fakeDb)).get('/health');
    expect(response.status).toBe(200);
    expect(response.body.status).toBe('ok');
  });

  it('requires keyword for search', async () => {
    const response = await request(createApp('v1.1', fakeDb)).get('/products/search');
    expect(response.status).toBe(400);
  });

  it('creates a product in v2', async () => {
    const response = await request(createApp('v2', fakeDb)).post('/products').send({
      name: 'Monitor', sku: 'MN-001', price: 199.99
    });
    expect(response.status).toBe(201);
    expect(response.body.sku).toBe('MN-001');
  });
});
