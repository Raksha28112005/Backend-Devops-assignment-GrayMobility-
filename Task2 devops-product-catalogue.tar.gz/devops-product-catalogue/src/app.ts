import express, { NextFunction, Request, Response } from 'express';
import { PrismaClient } from '@prisma/client';
import { z } from 'zod';

export type ApiVersion = 'v1' | 'v1.1' | 'v2';

const productInput = z.object({
  name: z.string().trim().min(1),
  description: z.string().trim().optional(),
  price: z.coerce.number().finite().nonnegative(),
  sku: z.string().trim().min(1)
});

const prisma = new PrismaClient();

export function createApp(version: ApiVersion = 'v2', db: PrismaClient = prisma) {
  const app = express();
  app.use(express.json({ limit: '100kb' }));

  app.get('/health', async (_req, res, next) => {
    try {
      await db.$queryRaw`SELECT 1`;
      res.status(200).json({ status: 'ok', version });
    } catch (error) {
      next(error);
    }
  });

  app.get('/products', async (_req, res, next) => {
    try {
      const products = await db.product.findMany({ orderBy: { id: 'asc' } });
      res.status(200).json(products);
    } catch (error) {
      next(error);
    }
  });

  // v1.1 and v2 expose keyword search. v2 additionally supports pagination and price bounds.
  if (version !== 'v1') {
    app.get('/products/search', async (req, res, next) => {
      try {
        const keyword = String(req.query.keyword ?? '').trim();
        if (!keyword) {
          return res.status(400).json({ error: 'keyword query parameter is required' });
        }

        const where: any = {
          OR: [
            { name: { contains: keyword, mode: 'insensitive' } },
            { description: { contains: keyword, mode: 'insensitive' } },
            { sku: { contains: keyword, mode: 'insensitive' } }
          ]
        };

        const options: any = { where, orderBy: { id: 'asc' } };
        if (version === 'v2') {
          const page = Math.max(1, Number(req.query.page ?? 1));
          const limit = Math.min(100, Math.max(1, Number(req.query.limit ?? 20)));
          options.skip = (page - 1) * limit;
          options.take = limit;
          if (req.query.minPrice !== undefined || req.query.maxPrice !== undefined) {
            where.price = {};
            if (req.query.minPrice !== undefined) where.price.gte = Number(req.query.minPrice);
            if (req.query.maxPrice !== undefined) where.price.lte = Number(req.query.maxPrice);
          }
        }

        const products = await db.product.findMany(options);
        return res.status(200).json(products);
      } catch (error) {
        return next(error);
      }
    });
  }

  if (version === 'v2') {
    app.post('/products', async (req, res, next) => {
      try {
        const parsed = productInput.safeParse(req.body);
        if (!parsed.success) return res.status(400).json({ error: 'Invalid product payload' });
        const product = await db.product.create({ data: parsed.data });
        return res.status(201).json(product);
      } catch (error: any) {
        if (error?.code === 'P2002') return res.status(409).json({ error: 'SKU already exists' });
        return next(error);
      }
    });
  }

  app.use((_req, res) => res.status(404).json({ error: 'Route not found' }));
  app.use((error: unknown, _req: Request, res: Response, _next: NextFunction) => {
    console.error(error);
    res.status(500).json({ error: 'Internal server error' });
  });

  return app;
}
