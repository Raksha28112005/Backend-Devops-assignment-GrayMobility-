import { createApp, ApiVersion } from './app';

const version = (process.env.API_VERSION ?? 'v2') as ApiVersion;
const port = Number(process.env.PORT ?? 3000);

if (!['v1', 'v1.1', 'v2'].includes(version)) {
  throw new Error('API_VERSION must be v1, v1.1, or v2');
}

createApp(version).listen(port, () => {
  console.log(`Product catalogue ${version} listening on port ${port}`);
});
