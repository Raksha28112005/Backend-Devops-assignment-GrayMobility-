# Changelog

## [2.0.0] - 2026-09-16
- Added query parameters `page`, `limit`, `minPrice`, and `maxPrice`.
- Added product creation with validation and duplicate-SKU handling.
- Added consistent error responses.

## [1.1.0]
- Added `/products/search?keyword=...`.

## [1.0.0]
- Added `/health` and `/products`.
