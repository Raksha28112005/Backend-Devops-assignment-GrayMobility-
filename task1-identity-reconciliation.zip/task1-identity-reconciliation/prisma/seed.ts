import { PrismaClient, LinkPrecedence } from "@prisma/client";

const prisma = new PrismaClient();

async function main() {
  await prisma.contact.deleteMany();

  await prisma.contact.create({
    data: {
      email: "doc@example.com",
      phoneNumber: "1111",
      linkPrecedence: LinkPrecedence.primary,
    },
  });

  console.log("Seed data inserted.");
}

main()
  .catch(console.error)
  .finally(() => prisma.$disconnect());