# System Design

## Architecture

Client -> Express HTTP API -> Identity reconciliation service -> Prisma -> PostgreSQL

## Data model

Each `Contact` has an ID, optional email, optional phone number, a nullable `linkedId`, a `linkPrecedence` enum, timestamps, and soft-delete support.

A primary contact has `linkPrecedence = primary` and normally has no `linkedId`. A secondary contact has `linkPrecedence = secondary` and points to the surviving primary using `linkedId`.

## Reconciliation rules

1. Normalize the incoming identifiers.
2. Search active contacts by email OR phone number.
3. If no records match, create a primary contact.
4. If records match, resolve each match to its root.
5. Select the oldest root as the surviving primary.
6. Convert any other root to secondary and repoint its descendants.
7. If the request contains an identifier not already in the connected component, create one secondary contact containing the new information.
8. Return the full connected component.

## Consistency

The operation runs in a serializable Prisma transaction. This reduces the chance of concurrent requests creating conflicting identity graphs. In a high-volume deployment, retry serialization failures with bounded exponential backoff.

## Performance

Indexes exist on email, phoneNumber, linkedId, and linkPrecedence. The matching query uses indexed equality comparisons. The implementation intentionally avoids loading unrelated contacts.

## Security

- Helmet sets common HTTP security headers.
- JSON body size is limited.
- Validation rejects malformed email values.
- Internal exceptions are logged on the server and hidden from API clients.
- Secrets are supplied through environment variables rather than committed files.
