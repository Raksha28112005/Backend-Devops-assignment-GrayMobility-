import { describe, expect, it } from "vitest";
import { normalizeEmail, normalizePhone } from "../src/normalization";

describe("normalization", () => {
  it("normalizes email addresses", () => {
    expect(normalizeEmail("  DOC@Example.COM ")).toBe("doc@example.com");
  });

  it("normalizes phone numbers to digits", () => {
    expect(normalizePhone("+91 987-654-3210")).toBe("919876543210");
  });

  it("turns blank values into null", () => {
    expect(normalizeEmail("   ")).toBeNull();
    expect(normalizePhone(" --- ")).toBeNull();
  });
});