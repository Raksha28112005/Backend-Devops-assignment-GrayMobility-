# Identity Reconciliation Service

A TypeScript/Express API backed by PostgreSQL and Prisma. It implements the `/identify` endpoint from the Backend - Identity Reconciliation assignment.

## Features

- Accepts `email` and/or `phoneNumber`.
- Creates a new `primary` contact when there is no match.
- Creates `secondary` contacts when new information is connected to an existing identity.
- Merges previously separate primary contacts when a request connects them.
- Normalizes emails and phone numbers.
- Uses a serializable database transaction to protect reconciliation operations.
- Includes safe error handling, indexes, comments, Docker support, and tests.

## Requirements

- Node.js 22+
- PostgreSQL 14+
- npm

## Local setup

1. Copy the environment file:

   ```bash
   cp .env.example .env
   ```

2. Install dependencies:

   ```bash
   npm install
   ```

3. Generate the Prisma client:

   ```bash
   npx prisma generate
   ```

4. Create the database schema:

   ```bash
   npx prisma migrate dev --name init
   ```

5. Start the development server:

   ```bash
   npm run dev
   ```

The API runs at `http://localhost:3000`.

## Run PostgreSQL with Docker

```bash
docker compose up -d postgres
npm install
npx prisma migrate dev --name init
npm run dev
```

## API

### Health check

```bash
curl http://localhost:3000/health
```

### Identify a contact

```bash
curl -X POST http://localhost:3000/identify \
  -H "Content-Type: application/json" \
  -d '{"email":"doc@example.com","phoneNumber":"9876543210"}'
```

Example response:

```json
{
  "primaryContactId": 1,
  "emails": ["doc@example.com"],
  "phoneNumbers": ["9876543210"],
  "secondaryContactIds": []
}
```

## Demonstration scenarios

### 1. Create a primary

```bash
curl -X POST http://localhost:3000/identify \
  -H "Content-Type: application/json" \
  -d '{"email":"doc@example.com","phoneNumber":"1111"}'
```

### 2. Add new information

```bash
curl -X POST http://localhost:3000/identify \
  -H "Content-Type: application/json" \
  -d '{"email":"doc2@example.com","phoneNumber":"1111"}'
```

The second request creates a secondary contact linked to the first contact.

### 3. Connect two previously separate identities

Create two separate contacts first, then send a request containing the email from one and the phone from the other. The older primary remains primary, and the newer primary becomes secondary.

## Tests

```bash
npm test
```

## Production build

```bash
npm run build
npm start
```

## Docker

```bash
docker compose up --build
```

The compose setup starts PostgreSQL, applies Prisma migrations, and starts the API.

## Design notes

- `createdAt` and `id` are used as a deterministic tie-breaker when choosing the surviving primary.
- Null values are never included in the response arrays.
- Repeating an already-known email/phone pair does not create duplicate contacts.
- The API never returns stack traces or database internals to clients.
- For a production system, add authentication, rate limiting, structured logging, metrics, and a migration/backup policy.
