import express, { NextFunction, Request, Response } from "express";
import cors from "cors";
import helmet from "helmet";
import { z } from "zod";
import { identify } from "./identity";

export const app = express();

app.use(helmet());
app.use(cors());
app.use(express.json({ limit: "10kb" }));

app.get("/health", (_req, res) => {
  res.status(200).json({ status: "ok" });
});

const identifySchema = z.object({
  email: z.string().trim().email().optional().nullable(),
  phoneNumber: z.union([z.string(), z.number()]).optional().nullable(),
}).refine(
  (value) => value.email != null || value.phoneNumber != null,
  { message: "email or phoneNumber is required" }
);

app.post("/identify", async (req: Request, res: Response, next: NextFunction) => {
  try {
    const parsed = identifySchema.parse(req.body);
    const result = await identify({
      email: parsed.email,
      phoneNumber: parsed.phoneNumber == null ? null : String(parsed.phoneNumber),
    });

    return res.status(200).json(result);
  } catch (error) {
    return next(error);
  }
});

/**
 * Safe error handler:
 * - Validation errors are reported as 400.
 * - Unexpected details are logged server-side only.
 * - Stack traces and database internals are not exposed to clients.
 */
app.use((error: unknown, _req: Request, res: Response, _next: NextFunction) => {
  if (error instanceof z.ZodError) {
    return res.status(400).json({
      error: "Invalid request",
      details: error.issues.map((issue) => issue.message),
    });
  }

  console.error(error);
  return res.status(500).json({ error: "Internal server error" });
});