/**
 * Normalization makes logically equivalent input values match consistently.
 * Email comparison is case-insensitive. Phone normalization keeps digits only.
 */
export function normalizeEmail(value: string | undefined | null): string | null {
  if (value == null) return null;
  const normalized = value.trim().toLowerCase();
  return normalized.length ? normalized : null;
}

export function normalizePhone(value: string | undefined | null): string | null {
  if (value == null) return null;
  const normalized = value.replace(/\D/g, "");
  return normalized.length ? normalized : null;
}