import { Prisma, PrismaClient, Contact, LinkPrecedence } from "@prisma/client";
import { normalizeEmail, normalizePhone } from "./normalization";

type DbClient = PrismaClient | Prisma.TransactionClient;

export type IdentifyInput = {
  email?: string | null;
  phoneNumber?: string | null;
};

export type IdentifyResponse = {
  primaryContactId: number;
  emails: string[];
  phoneNumbers: string[];
  secondaryContactIds: number[];
};

function unique<T>(values: T[]): T[] {
  return [...new Set(values)];
}

/**
 * Follows a contact's linkedId until it reaches the root.
 * The schema normally stores the root ID for every secondary contact.
 */
async function findRoot(db: DbClient, contact: Contact): Promise<Contact> {
  let current = contact;
  const visited = new Set<number>();

  while (current.linkPrecedence === LinkPrecedence.secondary && current.linkedId) {
    if (visited.has(current.id)) {
      throw new Error("Contact link cycle detected");
    }
    visited.add(current.id);

    const parent = await db.contact.findUnique({ where: { id: current.linkedId } });
    if (!parent) break;
    current = parent;
  }

  return current;
}

function toResponse(root: Contact, contacts: Contact[]): IdentifyResponse {
  const active = contacts.filter((contact) => contact.deletedAt === null);
  const ordered = [...active].sort((a, b) => {
    if (a.id === root.id) return -1;
    if (b.id === root.id) return 1;
    return a.id - b.id;
  });

  return {
    primaryContactId: root.id,
    emails: unique(ordered.map((c) => c.email).filter((v): v is string => Boolean(v))),
    phoneNumbers: unique(
      ordered.map((c) => c.phoneNumber).filter((v): v is string => Boolean(v))
    ),
    secondaryContactIds: ordered
      .filter((c) => c.id !== root.id)
      .map((c) => c.id),
  };
}

/**
 * Main reconciliation algorithm:
 * 1. Normalize input.
 * 2. Find contacts matching either supplied identifier.
 * 3. If no match exists, create a primary contact.
 * 4. If matches exist, resolve all roots and merge roots if necessary.
 * 5. Add a secondary contact only when the request contributes new information.
 * 6. Return the complete connected component.
 */
export async function identify(input: IdentifyInput): Promise<IdentifyResponse> {
  const email = normalizeEmail(input.email);
  const phoneNumber = normalizePhone(input.phoneNumber);

  if (!email && !phoneNumber) {
    throw new Error("At least one of email or phoneNumber is required");
  }

  return prisma.$transaction(
    async (tx) => {
      const matches = await tx.contact.findMany({
        where: {
          deletedAt: null,
          OR: [
            ...(email ? [{ email }] : []),
            ...(phoneNumber ? [{ phoneNumber }] : []),
          ],
        },
        orderBy: [{ createdAt: "asc" }, { id: "asc" }],
      });

      if (matches.length === 0) {
        const created = await tx.contact.create({
          data: {
            email,
            phoneNumber,
            linkPrecedence: LinkPrecedence.primary,
          },
        });

        return toResponse(created, [created]);
      }

      // Resolve every matching record to its current root.
      const roots = new Map<number, Contact>();
      for (const match of matches) {
        const root = await findRoot(tx, match);
        roots.set(root.id, root);
      }

      // The oldest root survives. Any other primary root becomes secondary.
      const sortedRoots = [...roots.values()].sort((a, b) => {
        const timeDifference = a.createdAt.getTime() - b.createdAt.getTime();
        return timeDifference || a.id - b.id;
      });
      const primary = sortedRoots[0];

      for (const root of sortedRoots.slice(1)) {
        await tx.contact.update({
          where: { id: root.id },
          data: {
            linkPrecedence: LinkPrecedence.secondary,
            linkedId: primary.id,
          },
        });

        // Repoint all existing descendants directly to the surviving root.
        await tx.contact.updateMany({
          where: { linkedId: root.id, deletedAt: null },
          data: { linkedId: primary.id },
        });
      }

      // Fetch the complete connected component after any merge.
      let connected = await tx.contact.findMany({
        where: {
          deletedAt: null,
          OR: [{ id: primary.id }, { linkedId: primary.id }],
        },
        orderBy: [{ createdAt: "asc" }, { id: "asc" }],
      });

      const knownEmails = new Set(connected.map((c) => c.email).filter(Boolean));
      const knownPhones = new Set(connected.map((c) => c.phoneNumber).filter(Boolean));

      const hasNewEmail = Boolean(email && !knownEmails.has(email));
      const hasNewPhone = Boolean(phoneNumber && !knownPhones.has(phoneNumber));

      // Do not create duplicates when the request contains only known values.
      if (hasNewEmail || hasNewPhone) {
        await tx.contact.create({
          data: {
            email: hasNewEmail ? email : null,
            phoneNumber: hasNewPhone ? phoneNumber : null,
            linkedId: primary.id,
            linkPrecedence: LinkPrecedence.secondary,
          },
        });
      }

      connected = await tx.contact.findMany({
        where: {
          deletedAt: null,
          OR: [{ id: primary.id }, { linkedId: primary.id }],
        },
        orderBy: [{ createdAt: "asc" }, { id: "asc" }],
      });

      return toResponse(primary, connected);
    },
    {
      isolationLevel: Prisma.TransactionIsolationLevel.Serializable,
      maxWait: 5000,
      timeout: 10000,
    }
  );
}